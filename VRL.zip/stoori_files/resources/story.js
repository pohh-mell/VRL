var story = {
 "pages": [
  {
   "image": "Avaleht.png",
   "width": 721,
   "links": [
    {
     "rect": [
      675,
      69,
      689,
      88
     ],
     "page": 6
    },
    {
     "rect": [
      268,
      268,
      287,
      289
     ],
     "page": 2
    },
    {
     "rect": [
      250,
      400,
      269,
      414
     ],
     "page": 9
    },
    {
     "rect": [
      610,
      276,
      625,
      289
     ],
     "page": 7
    }
   ],
   "title": "Avaleht",
   "height": 561
  },
  {
   "image": "kandidaadid.png",
   "width": 729,
   "links": [
    {
     "rect": [
      40,
      192,
      122,
      215
     ],
     "page": 4
    },
    {
     "rect": [
      128,
      272,
      142,
      292
     ],
     "page": 3
    }
   ],
   "title": "kandidaadid",
   "height": 553
  },
  {
   "image": "kandidaadidsisselogimata.png",
   "width": 729,
   "links": [{
    "rect": [
     113,
     283,
     129,
     300
    ],
    "page": 3
   }],
   "title": "kandidaadidsisselogimata",
   "height": 553
  },
  {
   "image": "kandidaadiinfo.png",
   "width": 808,
   "links": [],
   "title": "kandidaadiinfo",
   "height": 550
  },
  {
   "image": "Kandidaatvalitud.png",
   "width": 729,
   "links": [{
    "rect": [
     112,
     256,
     126,
     273
    ],
    "page": 3
   }],
   "title": "Kandidaatvalitud",
   "height": 553
  },
  {
   "image": "lisamine.png",
   "width": 745,
   "links": [],
   "title": "lisamine",
   "height": 497
  },
  {
   "image": "Sisselogitud.png",
   "width": 721,
   "links": [
    {
     "rect": [
      271,
      267,
      289,
      281
     ],
     "page": 1
    },
    {
     "rect": [
      666,
      406,
      681,
      425
     ],
     "page": 5
    },
    {
     "rect": [
      282,
      413,
      297,
      433
     ],
     "page": 9
    },
    {
     "rect": [
      639,
      283,
      657,
      297
     ],
     "page": 7
    }
   ],
   "title": "Sisselogitud",
   "height": 561
  },
  {
   "image": "statistika.png",
   "width": 769,
   "links": [{
    "rect": [
     456,
     432,
     666,
     481
    ],
    "page": 8
   }],
   "title": "statistika",
   "height": 537
  },
  {
   "image": "statistikavalitud.png",
   "width": 769,
   "links": [],
   "title": "statistikavalitud",
   "height": 537
  },
  {
   "image": "tulemused.png",
   "width": 769,
   "links": [],
   "title": "tulemused",
   "height": 529
  }
 ],
 "title": "stoori",
 "highlightLinks": false
}